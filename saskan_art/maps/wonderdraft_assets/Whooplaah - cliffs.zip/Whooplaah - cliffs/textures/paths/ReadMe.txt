~~~~~~~~~~~~ Example Custom Paths ~~~~~~~~~~~
The three red pngs, blue gradient and canal were made by me and you can do with them what you will.

BrickOldSharp0298_CG_bg.png and Checkeredtile01_kpl_64px.png were made by Bogie & Kepli of the Dundjinni user forums.  Assume personal use only.

The Rails and Road textures came from somewhere out on the net.  Assume personal use only.

~~~~~~~~ Installation ~~~~~~~~~~~~~
Unzip and place the "paths" folder under the Wonderdraft texture folder in your user directory.

%appdata%\Wonderdraft\assets\[your asset pack name]\textures\

Under Windows, open File Explorer (Windows-E) and type %appdata%\Wonderdraft in the address bar.

For all OSes, in Wonderdraft, select Open User Folder.

Note that you have to restart Wonderdraft for it to see the new paths.

~~~~~~~~~~~~~~~
2018-11-10 Phergus (/u/MrPhergus on Reddit)
